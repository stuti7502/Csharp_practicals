﻿//ABSTRACTION
namespace Practical8
{
    abstract class loginig
    {
        public abstract void login();
    }
    interface choices
    {
        public void choices();
    }
}