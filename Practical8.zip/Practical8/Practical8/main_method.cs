﻿class main_method
{
    public static void Main()
    {
        home_page hp = new home_page();
        hp.home();
    }
}